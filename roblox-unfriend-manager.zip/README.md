# Roblox Friend Manager (GitHub + Vercel Deployment)

This project provides a full web interface and backend proxy to manage and bulk-unfriend Roblox connections.

## Local Development
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start server:
   ```bash
   npm start
   ```
3. Open `http://localhost:3000` in your browser.

## Deploying to Vercel
1. Push this repository to your GitHub account.
2. Go to [Vercel](https://vercel.com), create a new project, and import your GitHub repository.
3. Deploy with default settings (Node.js runtime). No environment variables are required since credentials are provided directly in the UI session.
