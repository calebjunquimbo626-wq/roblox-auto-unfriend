const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors());

// Serve static frontend
app.use(express.static(path.join(__dirname, 'public')));

// Fetch user's friends
app.post('/api/friends', async (req, res) => {
    const { roblosecurity, userId } = req.body;
    if (!roblosecurity || !userId) {
        return res.status(400).json({ success: false, error: 'Missing credentials or User ID.' });
    }
    try {
        const response = await axios.get(`https://friends.roblox.com/v1/users/${userId}/friends`, {
            headers: {
                'Cookie': `.ROBLOSECURITY=${roblosecurity}`
            }
        });
        res.json({ success: true, friends: response.data.data });
    } catch (error) {
        res.status(400).json({ success: false, error: error.response?.data || error.message });
    }
});

// Helper to handle CSRF tokens and unfriend logic
app.post('/api/unfriend', async (req, res) => {
    const { roblosecurity, targetUserId } = req.body;
    if (!roblosecurity || !targetUserId) {
        return res.status(400).json({ success: false, error: 'Missing credentials or Target User ID.' });
    }

    const unfriendRequest = async (csrfToken = '') => {
        return await axios.post(
            `https://friends.roblox.com/v1/users/${targetUserId}/unfriend`,
            {},
            {
                headers: {
                    'Cookie': `.ROBLOSECURITY=${roblosecurity}`,
                    'x-csrf-token': csrfToken,
                    'Content-Type': 'application/json'
                }
            }
        );
    };

    try {
        await unfriendRequest();
        res.json({ success: true, targetUserId });
    } catch (error) {
        if (error.response && error.response.status === 403 && error.response.headers['x-csrf-token']) {
            const newCsrfToken = error.response.headers['x-csrf-token'];
            try {
                await unfriendRequest(newCsrfToken);
                return res.json({ success: true, targetUserId });
            } catch (retryError) {
                return res.status(400).json({ success: false, error: retryError.response?.data || retryError.message });
            }
        }
        res.status(400).json({ success: false, error: error.response?.data || error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

module.exports = app;
